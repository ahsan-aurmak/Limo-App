import {
  Alert,
  App as AntdApp,
  Avatar,
  Button,
  Card,
  Col,
  ConfigProvider,
  Divider,
  Dropdown,
  Form,
  Input,
  Layout,
  Menu,
  Modal,
  Progress,
  Row,
  Select,
  Space,
  Statistic,
  Steps,
  Table,
  Tag,
  Typography,
  Upload,
  message,
} from "antd";
import type { MenuProps, TableProps, UploadProps } from "antd";
import {
  ApiOutlined,
  DashboardOutlined,
  CheckCircleOutlined,
  CloudUploadOutlined,
  FileDoneOutlined,
  LinkOutlined,
  SafetyOutlined,
  SyncOutlined,
} from "@ant-design/icons";
import {
  DownOutlined,
  LogoutOutlined,
  SettingOutlined,
  UserOutlined,
} from "@ant-design/icons";
import { useEffect, useState } from "react";
import uberLogo from "./assets/uber.svg";
import careemLogo from "./assets/careem.svg";
import indriveLogo from "./assets/indrive.svg";

type MenuKey = "dashboard" | "connectors" | "daily";
type Platform = "UBER" | "CAREEM" | "INDRIVE";
type Mode = "API" | "UPLOAD";
type AuthMethod = "OAUTH_CLIENT_CREDENTIALS" | "API_KEY" | "BEARER_TOKEN";
type ConnectorFormValues = {
  accountId?: string;
  authMethod?: AuthMethod;
  clientId?: string;
  clientSecret?: string;
  apiKey?: string;
  apiSecret?: string;
  accessToken?: string;
};
type ConnectorPreferences = {
  modes: Record<Platform, Mode>;
  authMethods: Record<Platform, AuthMethod>;
};
type LoginFormValues = {
  username: string;
  password: string;
};

type PlatformRow = {
  key: string;
  platform: Platform;
  mode: string;
  todayImported: number;
  readyForLes: number;
  failed: number;
  status: "good" | "attention";
};

const platformLogoMap: Record<Platform, string> = {
  UBER: uberLogo,
  CAREEM: careemLogo,
  INDRIVE: indriveLogo,
};

const platformNameMap: Record<Platform, string> = {
  UBER: "Uber",
  CAREEM: "Careem",
  INDRIVE: "inDrive",
};

const authMethodLabelMap: Record<AuthMethod, string> = {
  OAUTH_CLIENT_CREDENTIALS: "OAuth Client Credentials",
  API_KEY: "API Key",
  BEARER_TOKEN: "Bearer Token",
};

const menuItems: MenuProps["items"] = [
  { key: "dashboard", icon: <DashboardOutlined />, label: "Dashboard" },
  { key: "connectors", icon: <LinkOutlined />, label: "Connect Data Sources" },
  { key: "daily", icon: <SafetyOutlined />, label: "Daily Work" },
];

const initialPlatformRows: PlatformRow[] = [
  {
    key: "1",
    platform: "UBER",
    mode: "API Connector",
    todayImported: 624,
    readyForLes: 601,
    failed: 8,
    status: "good",
  },
  {
    key: "2",
    platform: "CAREEM",
    mode: "Export Upload",
    todayImported: 221,
    readyForLes: 184,
    failed: 14,
    status: "attention",
  },
  {
    key: "3",
    platform: "INDRIVE",
    mode: "Export Upload",
    todayImported: 152,
    readyForLes: 110,
    failed: 11,
    status: "attention",
  },
];

type LesRunScope =
  | { type: "ready-all" }
  | { type: "failed-all" }
  | { type: "failed-platform"; platform: Platform };

const lesSubmissionStages = [
  "Validating ready trips",
  "Refreshing LES authentication token",
  "Submitting trips in batches",
  "Finalizing reconciliation data",
] as const;

const lesLikelyFailureReasonsCatalog = [
  "Driver profile is missing mandatory LES fields.",
  "Vehicle data is incomplete for LES payload.",
  "Pickup time format is invalid for LES.",
  "Missing mandatory fallback identity fields.",
  "LES request timeout while saving batch.",
] as const;

const PlatformBrand = ({ platform }: { platform: Platform }) => (
  <Space size={8}>
    <img src={platformLogoMap[platform]} alt={`${platformNameMap[platform]} logo`} className="platform-logo" />
    <Typography.Text>{platformNameMap[platform]}</Typography.Text>
  </Space>
);

const CONNECTOR_PREFS_STORAGE_KEY = "carmak.connector.preferences.v1";

const defaultModes: Record<Platform, Mode> = {
  UBER: "API",
  CAREEM: "UPLOAD",
  INDRIVE: "UPLOAD",
};

const defaultAuthMethods: Record<Platform, AuthMethod> = {
  UBER: "OAUTH_CLIENT_CREDENTIALS",
  CAREEM: "API_KEY",
  INDRIVE: "API_KEY",
};

const APP_LOGIN_CREDENTIALS = {
  username: "operator",
  password: "Carmak@2026",
} as const;

const readConnectorPreferences = (): ConnectorPreferences | null => {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(CONNECTOR_PREFS_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as ConnectorPreferences;
    if (!parsed.modes || !parsed.authMethods) return null;
    return parsed;
  } catch {
    return null;
  }
};

const App = () => {
  const savedPreferences = readConnectorPreferences();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeMenu, setActiveMenu] = useState<MenuKey>("dashboard");
  const [uberMode, setUberMode] = useState<Mode>(savedPreferences?.modes.UBER ?? defaultModes.UBER);
  const [careemMode, setCareemMode] = useState<Mode>(savedPreferences?.modes.CAREEM ?? defaultModes.CAREEM);
  const [indriveMode, setIndriveMode] = useState<Mode>(savedPreferences?.modes.INDRIVE ?? defaultModes.INDRIVE);
  const [authMethods, setAuthMethods] = useState<Record<Platform, AuthMethod>>(
    savedPreferences?.authMethods ?? defaultAuthMethods,
  );
  const [uberForm] = Form.useForm<ConnectorFormValues>();
  const [careemForm] = Form.useForm<ConnectorFormValues>();
  const [indriveForm] = Form.useForm<ConnectorFormValues>();
  const [loginForm] = Form.useForm<LoginFormValues>();
  const [api, contextHolder] = message.useMessage();
  const [testingConnections, setTestingConnections] = useState<Record<Platform, boolean>>({
    UBER: false,
    CAREEM: false,
    INDRIVE: false,
  });
  const [lesModalOpen, setLesModalOpen] = useState(false);
  const [lesSubmitting, setLesSubmitting] = useState(false);
  const [lesProgress, setLesProgress] = useState(0);
  const [lesCurrentStage, setLesCurrentStage] = useState(0);
  const [lesFailedStageIndex, setLesFailedStageIndex] = useState<number | null>(null);
  const [lesSubmissionLog, setLesSubmissionLog] = useState<string[]>([]);
  const [lesSummary, setLesSummary] = useState({
    ready: 0,
    submitted: 0,
    failed: 0,
  });
  const [lesLikelyFailureReasons, setLesLikelyFailureReasons] = useState<
    Array<{ reason: string; count: number }>
  >([]);
  const [platformStats, setPlatformStats] = useState<PlatformRow[]>(initialPlatformRows);

  const uploadProps = (platform: Platform): UploadProps => ({
    maxCount: 1,
    showUploadList: false,
    beforeUpload: (file) => {
      api.success(`${platform} file "${file.name}" uploaded. Parsing started.`);
      return false;
    },
  });

  const selectedModes: Record<Platform, Mode> = {
    UBER: uberMode,
    CAREEM: careemMode,
    INDRIVE: indriveMode,
  };

  const resetAppToDefaults = () => {
    if (typeof window !== "undefined") {
      window.localStorage.removeItem(CONNECTOR_PREFS_STORAGE_KEY);
    }
    setActiveMenu("dashboard");
    setUberMode(defaultModes.UBER);
    setCareemMode(defaultModes.CAREEM);
    setIndriveMode(defaultModes.INDRIVE);
    setAuthMethods(defaultAuthMethods);
    setTestingConnections({
      UBER: false,
      CAREEM: false,
      INDRIVE: false,
    });
    setPlatformStats(initialPlatformRows.map((row) => ({ ...row })));
    setLesModalOpen(false);
    setLesSubmitting(false);
    setLesProgress(0);
    setLesCurrentStage(0);
    setLesFailedStageIndex(null);
    setLesSubmissionLog([]);
    setLesSummary({
      ready: 0,
      submitted: 0,
      failed: 0,
    });
    setLesLikelyFailureReasons([]);
    uberForm.resetFields();
    careemForm.resetFields();
    indriveForm.resetFields();
    loginForm.resetFields();
    uberForm.setFieldsValue({ authMethod: defaultAuthMethods.UBER });
    careemForm.setFieldsValue({ authMethod: defaultAuthMethods.CAREEM });
    indriveForm.setFieldsValue({ authMethod: defaultAuthMethods.INDRIVE });
  };

  useEffect(() => {
    const payload: ConnectorPreferences = {
      modes: selectedModes,
      authMethods,
    };
    window.localStorage.setItem(CONNECTOR_PREFS_STORAGE_KEY, JSON.stringify(payload));
  }, [uberMode, careemMode, indriveMode, authMethods]);

  const setAuthMethodForPlatform = (platform: Platform, method: AuthMethod) => {
    setAuthMethods((previous) => ({
      ...previous,
      [platform]: method,
    }));
  };

  const getFormForPlatform = (platform: Platform) => {
    if (platform === "UBER") return uberForm;
    if (platform === "CAREEM") return careemForm;
    return indriveForm;
  };

  const setModeForPlatform = (platform: Platform, mode: Mode) => {
    if (platform === "UBER") setUberMode(mode);
    if (platform === "CAREEM") setCareemMode(mode);
    if (platform === "INDRIVE") setIndriveMode(mode);
    api.success(`${platformNameMap[platform]} data mode set to ${mode === "API" ? "API Connector" : "Export Upload"}.`);
  };

  const onTestConnection = async (platform: Platform) => {
    const form = getFormForPlatform(platform);
    try {
      await form.validateFields();
      setTestingConnections((previous) => ({ ...previous, [platform]: true }));
      const simulatedLatencyMs = 700 + Math.floor(Math.random() * 1200);
      await new Promise((resolve) => setTimeout(resolve, simulatedLatencyMs));
      const isSuccess = Math.random() < 0.65;

      if (isSuccess) {
        api.success(
          `${platformNameMap[platform]} connection test passed (${simulatedLatencyMs} ms).`,
        );
      } else {
        const failureReasons = [
          "Authentication failed (invalid credential or token expired).",
          "Account access denied (insufficient scope/permissions).",
          "Rate limit reached. Please retry shortly.",
          "Network timeout while contacting provider API.",
        ];
        const randomReason = failureReasons[Math.floor(Math.random() * failureReasons.length)];
        api.error(`${platformNameMap[platform]} connection test failed: ${randomReason}`);
      }
    } catch {
      api.error(`Please complete required ${platformNameMap[platform]} fields before testing.`);
    } finally {
      setTestingConnections((previous) => ({ ...previous, [platform]: false }));
    }
  };

  const onSaveConnector = async (platform: Platform) => {
    const form = getFormForPlatform(platform);
    try {
      await form.validateFields();
      api.success(`${platformNameMap[platform]} connector saved.`);
    } catch {
      api.error(`Please fill all required ${platformNameMap[platform]} connector fields.`);
    }
  };

  const runLesSubmissionSimulation = async (scope: LesRunScope = { type: "ready-all" }) => {
    if (lesSubmitting) return;

    const scopedRows = platformRowsWithSelectedMode
      .filter((row) => {
        if (scope.type === "ready-all") return row.readyForLes > 0;
        if (scope.type === "failed-all") return row.failed > 0;
        return row.platform === scope.platform && row.failed > 0;
      })
      .map((row) => ({
        platform: row.platform,
        trips: scope.type === "ready-all" ? row.readyForLes : row.failed,
      }));

    const totalReady = scopedRows.reduce((sum, row) => sum + row.trips, 0);
    if (totalReady <= 0) {
      api.info(scope.type === "ready-all" ? "No ready trips available to submit." : "No failed trips available to resubmit.");
      return;
    }
    const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

    const runLabel =
      scope.type === "ready-all"
        ? `Starting LES submission for ${totalReady} ready trips...`
        : scope.type === "failed-all"
          ? `Starting LES resubmission for ${totalReady} failed trips...`
          : `Starting LES resubmission for ${platformNameMap[scope.platform]} failed trips (${totalReady})...`;

    setLesModalOpen(true);
    setLesSubmitting(true);
    setLesProgress(0);
    setLesCurrentStage(0);
    setLesFailedStageIndex(null);
    setLesSubmissionLog([runLabel]);
    setLesSummary({
      ready: totalReady,
      submitted: 0,
      failed: 0,
    });
    setLesLikelyFailureReasons([]);

    setLesCurrentStage(0);
    setLesProgress(12);
    setLesSubmissionLog((prev) => [...prev, "Stage 1/4: Validation completed."]);
    await wait(700);

    setLesCurrentStage(1);
    setLesProgress(30);
    setLesSubmissionLog((prev) => [...prev, "Stage 2/4: LES token refreshed."]);
    await wait(800);

    const tokenFailure = Math.random() < 0.08;
    if (tokenFailure) {
      setLesFailedStageIndex(1);
      setLesSubmitting(false);
      setLesSummary({
        ready: totalReady,
        submitted: 0,
        failed: totalReady,
      });
      setLesLikelyFailureReasons([{ reason: "LES authentication failed (token issue).", count: totalReady }]);
      setLesSubmissionLog((prev) => [...prev, "Submission stopped: LES authentication failed."]);
      api.error("LES submission failed at authentication stage. Please retry.");
      return;
    }

    setLesCurrentStage(2);
    setLesProgress(40);

    const batchCount = 5;
    const failureRate = 0.01 + Math.random() * 0.05;
    let processed = 0;
    let submitted = 0;
    let failed = 0;
    const reasonCounter = new Map<string, number>();

    for (let batch = 1; batch <= batchCount; batch += 1) {
      await wait(500 + Math.floor(Math.random() * 500));
      const remaining = totalReady - processed;
      const batchSize = batch === batchCount ? remaining : Math.max(1, Math.round(totalReady / batchCount));
      const actualBatch = Math.min(batchSize, remaining);
      const batchFailed = Math.min(
        actualBatch,
        Math.round(actualBatch * failureRate * (0.7 + Math.random() * 0.6)),
      );
      const batchSubmitted = actualBatch - batchFailed;

      processed += actualBatch;
      submitted += batchSubmitted;
      failed += batchFailed;

      setLesSummary({
        ready: totalReady,
        submitted,
        failed,
      });
      if (batchFailed > 0) {
        const failureReason =
          lesLikelyFailureReasonsCatalog[Math.floor(Math.random() * lesLikelyFailureReasonsCatalog.length)];
        reasonCounter.set(failureReason, (reasonCounter.get(failureReason) ?? 0) + batchFailed);
      }
      setLesProgress(40 + Math.round((processed / Math.max(totalReady, 1)) * 45));
      setLesSubmissionLog((prev) => [
        ...prev,
        `Batch ${batch}/${batchCount}: submitted ${batchSubmitted}, failed ${batchFailed}.`,
      ]);
    }

    setLesCurrentStage(3);
    setLesProgress(92);
    setLesSubmissionLog((prev) => [...prev, "Stage 4/4: Reconciliation snapshot generated."]);
    await wait(700);

    setLesProgress(100);
    setLesSubmitting(false);
    const likelyReasons = [...reasonCounter.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([reason, count]) => ({ reason, count }));
    setLesLikelyFailureReasons(likelyReasons);

    const distributeFailuresByPlatform = (
      rows: Array<{ platform: Platform; trips: number }>,
      totalFailedTrips: number,
    ) => {
      const totalTrips = rows.reduce((sum, row) => sum + row.trips, 0);
      if (totalFailedTrips <= 0 || totalTrips <= 0) {
        return new Map<Platform, number>(rows.map((row) => [row.platform, 0]));
      }

      const allocations = rows.map((row) => {
        const exact = (row.trips / totalTrips) * totalFailedTrips;
        return {
          platform: row.platform,
          count: Math.floor(exact),
          remainder: exact - Math.floor(exact),
        };
      });
      let remaining = totalFailedTrips - allocations.reduce((sum, row) => sum + row.count, 0);
      allocations.sort((a, b) => b.remainder - a.remainder);

      for (let index = 0; index < allocations.length && remaining > 0; index += 1) {
        allocations[index].count += 1;
        remaining -= 1;
      }

      return new Map<Platform, number>(allocations.map((row) => [row.platform, row.count]));
    };

    const failedByPlatform = distributeFailuresByPlatform(scopedRows, failed);
    setPlatformStats((previous) =>
      previous.map((row) => {
        const targetScope = scopedRows.find((scoped) => scoped.platform === row.platform);
        if (!targetScope) return row;

        const remainingFailedForScope = failedByPlatform.get(row.platform) ?? 0;
        const status = remainingFailedForScope > 0 ? "attention" : "good";

        if (scope.type === "ready-all") {
          return {
            ...row,
            readyForLes: Math.max(row.readyForLes - targetScope.trips, 0),
            failed: row.failed + remainingFailedForScope,
            status: row.failed + remainingFailedForScope > 0 ? "attention" : "good",
          };
        }

        return {
          ...row,
          failed: remainingFailedForScope,
          status,
        };
      }),
    );

    if (failed > 0) {
      api.warning(`LES submission finished with ${failed} failed trips. Review failed queue.`);
    } else {
      api.success("LES submission finished successfully.");
    }
  };

  const onProfileAction: MenuProps["onClick"] = ({ key }) => {
    if (key === "account") {
      api.info("Account settings panel will be connected in next iteration.");
      return;
    }
    if (key === "company") {
      api.info("Company profile settings panel will be connected in next iteration.");
      return;
    }
    if (key === "logout") {
      resetAppToDefaults();
      setIsAuthenticated(false);
      api.success("Logged out. App has been reset to default.");
    }
  };

  const onLogin = async () => {
    try {
      const values = await loginForm.validateFields();
      if (
        values.username !== APP_LOGIN_CREDENTIALS.username ||
        values.password !== APP_LOGIN_CREDENTIALS.password
      ) {
        loginForm.setFieldValue("password", "");
        api.error("Invalid username or password.");
        return;
      }
      setIsAuthenticated(true);
      api.success("Logged in.");
    } catch {
      api.error("Please enter username and password.");
    }
  };

  const platformRowsWithSelectedMode: PlatformRow[] = platformStats.map((row) => ({
    ...row,
    mode: selectedModes[row.platform] === "API" ? "API Connector" : "Export Upload",
  }));

  const tableColumns: TableProps<PlatformRow>["columns"] = [
    {
      title: "Platform",
      dataIndex: "platform",
      key: "platform",
      render: (platform: Platform) => <PlatformBrand platform={platform} />,
    },
    {
      title: "Data Mode",
      dataIndex: "mode",
      key: "mode",
      render: (mode: string) => <Tag color={mode === "API Connector" ? "blue" : "default"}>{mode}</Tag>,
    },
    {
      title: "Imported Today",
      dataIndex: "todayImported",
      key: "todayImported",
    },
    {
      title: "Ready for LES",
      dataIndex: "readyForLes",
      key: "readyForLes",
    },
    {
      title: "Failed",
      dataIndex: "failed",
      key: "failed",
      render: (failed: number) => <Tag color={failed > 0 ? "warning" : "success"}>{failed}</Tag>,
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (_status: PlatformRow["status"], row) => (
        <Tag color={row.failed > 0 ? "orange" : "green"}>{row.failed > 0 ? "Needs Action" : "Good"}</Tag>
      ),
    },
    {
      title: "Action",
      key: "action",
      render: (_value, row) =>
        row.failed > 0 ? (
          <Button
            size="small"
            icon={<SyncOutlined />}
            disabled={lesSubmitting}
            loading={lesSubmitting}
            onClick={() => void runLesSubmissionSimulation({ type: "failed-platform", platform: row.platform })}
          >
            Resubmit Failed
          </Button>
        ) : (
          <Typography.Text type="secondary">No failed trips</Typography.Text>
        ),
    },
  ];

  const dashboardTotals = platformRowsWithSelectedMode.reduce(
    (acc, row) => ({
      imported: acc.imported + row.todayImported,
      ready: acc.ready + row.readyForLes,
      failed: acc.failed + row.failed,
    }),
    { imported: 0, ready: 0, failed: 0 },
  );

  const renderApiConnectorForm = (platform: Platform) => {
    const authMethod = authMethods[platform];
    const platformName = platformNameMap[platform];
    const form = getFormForPlatform(platform);

    return (
      <Form
        form={form}
        layout="vertical"
        requiredMark
        initialValues={{ authMethod }}
      >
        <Form.Item
          label="Account / Organization ID"
          name="accountId"
          rules={[{ required: true, message: "Account / Organization ID is required." }]}
          extra="Use the enterprise account ID provided by the platform."
        >
          <Input placeholder={`Your ${platformName} enterprise account ID`} />
        </Form.Item>
        <Form.Item
          label="Authentication Method"
          name="authMethod"
          rules={[{ required: true, message: "Authentication method is required." }]}
          extra="Choose the method enabled on your platform account."
        >
          <Select
            value={authMethod}
            onChange={(value: AuthMethod) => {
              setAuthMethodForPlatform(platform, value);
              form.setFieldValue("authMethod", value);
            }}
            options={[
              { value: "OAUTH_CLIENT_CREDENTIALS", label: authMethodLabelMap.OAUTH_CLIENT_CREDENTIALS },
              { value: "API_KEY", label: authMethodLabelMap.API_KEY },
              { value: "BEARER_TOKEN", label: authMethodLabelMap.BEARER_TOKEN },
            ]}
          />
        </Form.Item>

        {authMethod === "OAUTH_CLIENT_CREDENTIALS" && (
          <>
            <Form.Item
              label="Client ID"
              name="clientId"
              preserve={false}
              rules={[{ required: true, message: "Client ID is required." }]}
            >
              <Input placeholder={`Paste ${platformName} client ID`} />
            </Form.Item>
            <Form.Item
              label="Client Secret"
              name="clientSecret"
              preserve={false}
              rules={[{ required: true, message: "Client Secret is required." }]}
            >
              <Input.Password placeholder={`Paste ${platformName} client secret`} />
            </Form.Item>
          </>
        )}

        {authMethod === "API_KEY" && (
          <>
            <Form.Item
              label="API Key"
              name="apiKey"
              preserve={false}
              rules={[{ required: true, message: "API Key is required." }]}
            >
              <Input.Password placeholder={`Paste ${platformName} API key`} />
            </Form.Item>
            <Form.Item
              label="API Secret (if required)"
              name="apiSecret"
              preserve={false}
              extra="Leave blank only if this platform does not issue API secrets."
            >
              <Input.Password placeholder={`Paste ${platformName} API secret (optional if not required)`} />
            </Form.Item>
          </>
        )}

        {authMethod === "BEARER_TOKEN" && (
          <Form.Item
            label="Access Token"
            name="accessToken"
            preserve={false}
            rules={[{ required: true, message: "Access Token is required." }]}
            extra="Paste full token exactly as received from the platform."
          >
            <Input.Password placeholder={`Paste ${platformName} access token`} />
          </Form.Item>
        )}

        <Space>
          <Button type="primary" icon={<CheckCircleOutlined />} onClick={() => void onSaveConnector(platform)}>
            Save {platformName} API Connector
          </Button>
          <Button
            icon={<SyncOutlined />}
            loading={testingConnections[platform]}
            disabled={testingConnections[platform]}
            onClick={() => void onTestConnection(platform)}
          >
            Test Connection
          </Button>
        </Space>
      </Form>
    );
  };

  const renderDashboard = () => (
    <Space direction="vertical" size={16} className="w-full">
      <Alert
        type="warning"
        showIcon
        message="Compliance Dashboard"
        description="Track imports and submit trips to LES with the minimum daily actions."
      />
      <Card className="glass-card">
        <Space wrap size={24} className="platform-strip">
          <PlatformBrand platform="UBER" />
          <PlatformBrand platform="CAREEM" />
          <PlatformBrand platform="INDRIVE" />
        </Space>
      </Card>

      <Row gutter={16}>
        <Col xs={24} md={8}>
          <Card className="glass-card">
            <Statistic title="Imported Today" value={dashboardTotals.imported} />
          </Card>
        </Col>
        <Col xs={24} md={8}>
          <Card className="glass-card">
            <Statistic title="Ready for LES" value={dashboardTotals.ready} />
          </Card>
        </Col>
        <Col xs={24} md={8}>
          <Card className="glass-card">
            <Statistic title="Needs Fix / Failed" value={dashboardTotals.failed} valueStyle={{ color: "#b91c1c" }} />
          </Card>
        </Col>
      </Row>

      <Card className="glass-card" title="Operational View: Platform Pipeline Today">
        <Table columns={tableColumns} dataSource={platformRowsWithSelectedMode} pagination={false} />
      </Card>

      <Card className="glass-card" title="Priority Actions">
        <Space wrap>
          <Button type="primary" icon={<ApiOutlined />} onClick={() => setActiveMenu("connectors")}>
            Configure Connectors
          </Button>
          <Button icon={<CloudUploadOutlined />} onClick={() => setActiveMenu("daily")}>
            Run Daily Processing
          </Button>
          <Button icon={<FileDoneOutlined />}>Open Failed Trips Queue</Button>
        </Space>
      </Card>
    </Space>
  );

  const renderConnectors = () => (
    <Space direction="vertical" size={16} className="w-full">
      <Alert
        type="info"
        showIcon
        message="Choose data mode per platform: API Connector or Export Upload"
        description="All platforms support both options in Carmak. Select what your company has access to."
      />

      <Card
        className="glass-card"
        title={
          <Space size={10}>
            <img src={platformLogoMap.UBER} alt="Uber logo" className="platform-logo-large" />
            <span>Uber</span>
          </Space>
        }
      >
        <Row gutter={16}>
          <Col xs={24}>
            <Typography.Text strong>Choose data mode</Typography.Text>
            <Select
              value={uberMode}
              onChange={(value: Mode) => setModeForPlatform("UBER", value)}
              options={[
                { value: "API", label: "API Connector" },
                { value: "UPLOAD", label: "Export Upload" },
              ]}
              className="field-full top-gap"
            />
            <Typography.Text type="secondary">Required: choose one mode before continuing.</Typography.Text>
            <Divider />
            {uberMode === "API" ? (
              renderApiConnectorForm("UBER")
            ) : (
              <Space direction="vertical">
                <Typography.Text>1) Export trip file from Uber enterprise portal.</Typography.Text>
                <Typography.Text>2) Upload file in Daily Work page.</Typography.Text>
                <Typography.Text>3) App validates and submits ready trips to LES.</Typography.Text>
              </Space>
            )}
          </Col>
        </Row>
      </Card>

      <Card
        className="glass-card"
        title={
          <Space size={10}>
            <img src={platformLogoMap.CAREEM} alt="Careem logo" className="platform-logo-large" />
            <span>Careem</span>
          </Space>
        }
      >
        <Row gutter={16}>
          <Col xs={24}>
            <Typography.Text strong>Choose data mode</Typography.Text>
            <Select
              value={careemMode}
              onChange={(value: Mode) => setModeForPlatform("CAREEM", value)}
              options={[
                { value: "API", label: "API Connector" },
                { value: "UPLOAD", label: "Export Upload" },
              ]}
              className="field-full top-gap"
            />
            <Typography.Text type="secondary">Required: choose one mode before continuing.</Typography.Text>
            <Divider />
            {careemMode === "UPLOAD" ? (
              <Space direction="vertical">
                <Typography.Text>1) Export trip file from Careem enterprise portal.</Typography.Text>
                <Typography.Text>2) Upload file in Daily Work page.</Typography.Text>
                <Typography.Text>3) App validates and submits ready trips to LES.</Typography.Text>
              </Space>
            ) : (
              renderApiConnectorForm("CAREEM")
            )}
          </Col>
        </Row>
      </Card>

      <Card
        className="glass-card"
        title={
          <Space size={10}>
            <img src={platformLogoMap.INDRIVE} alt="inDrive logo" className="platform-logo-large" />
            <span>inDrive</span>
          </Space>
        }
      >
        <Row gutter={16}>
          <Col xs={24}>
            <Typography.Text strong>Choose data mode</Typography.Text>
            <Select
              value={indriveMode}
              onChange={(value: Mode) => setModeForPlatform("INDRIVE", value)}
              options={[
                { value: "API", label: "API Connector" },
                { value: "UPLOAD", label: "Export Upload" },
              ]}
              className="field-full top-gap"
            />
            <Typography.Text type="secondary">Required: choose one mode before continuing.</Typography.Text>
            <Divider />
            {indriveMode === "UPLOAD" ? (
              <Space direction="vertical">
                <Typography.Text>1) Export trip file from inDrive enterprise account.</Typography.Text>
                <Typography.Text>2) Upload file in Daily Work page.</Typography.Text>
                <Typography.Text>3) Fix flagged rows and submit to LES.</Typography.Text>
              </Space>
            ) : (
              renderApiConnectorForm("INDRIVE")
            )}
          </Col>
        </Row>
      </Card>
    </Space>
  );

  const renderDailyPlatformCard = (platform: Platform, label: string) => {
    const currentMode = selectedModes[platform];
    const platformTitle = currentMode === "API" ? "API Sync" : "Export Upload";
    const authMethod = authMethods[platform];

    return (
      <Card
        className="glass-card"
        title={
          <Space size={10}>
            <img src={platformLogoMap[platform]} alt={`${platformNameMap[platform]} logo`} className="platform-logo-large" />
            <span>
              {label}: {platformNameMap[platform]} ({platformTitle})
            </span>
          </Space>
        }
      >
        {currentMode === "API" ? (
          <Space direction="vertical">
            <Button type="primary" icon={<SyncOutlined />}>
              Sync {platformNameMap[platform]} API Trips
            </Button>
            <Typography.Text type="secondary">
              Using API connector mode ({authMethodLabelMap[authMethod]}). You can switch mode in Connect Data Sources.
            </Typography.Text>
          </Space>
        ) : (
          <Upload.Dragger {...uploadProps(platform)}>
            <p className="ant-upload-text">Drop {platformNameMap[platform]} CSV/XLSX here</p>
            <p className="ant-upload-hint">Using export upload mode. You can switch to API mode in Connect Data Sources.</p>
          </Upload.Dragger>
        )}
      </Card>
    );
  };

  const renderDaily = () => (
    <Space direction="vertical" size={16} className="w-full">
      <Alert
        type="success"
        showIcon
        message="Daily guide based on your selected mode per platform"
        description="For each platform below, run API sync or upload export file based on the mode chosen in Connect Data Sources."
      />
      <Row gutter={16}>
        <Col xs={24} md={12}>
          {renderDailyPlatformCard("UBER", "Step 1")}
        </Col>
        <Col xs={24} md={12}>
          {renderDailyPlatformCard("CAREEM", "Step 2")}
        </Col>
        <Col xs={24} md={12}>
          {renderDailyPlatformCard("INDRIVE", "Step 3")}
        </Col>
        <Col xs={24} md={12}>
          <Card className="glass-card" title="Step 4: Validate and Submit to LES">
            <Space wrap>
              <Button icon={<FileDoneOutlined />}>Validate Imported Trips</Button>
              <Button type="primary" icon={<CheckCircleOutlined />} onClick={() => void runLesSubmissionSimulation()}>
                Submit All Ready Trips to LES
              </Button>
              <Button>Download Daily Compliance Report</Button>
            </Space>
          </Card>
        </Col>
      </Row>

      <Card className="glass-card" title="Today by Platform">
        <Table columns={tableColumns} dataSource={platformRowsWithSelectedMode} pagination={false} />
      </Card>
      <Card className="glass-card">
        <Typography.Text strong>Need help?</Typography.Text>
        <Typography.Paragraph className="bottom-zero">
          If a row fails, open the <Tag color="warning">Needs Action</Tag> queue, edit missing fields, and click
          submit again.
        </Typography.Paragraph>
      </Card>
    </Space>
  );

  const renderContent = () => {
    if (activeMenu === "connectors") return renderConnectors();
    if (activeMenu === "daily") return renderDaily();
    return renderDashboard();
  };

  const profileMenuItems: MenuProps["items"] = [
    {
      key: "account",
      icon: <UserOutlined />,
      label: "My Account",
    },
    {
      key: "company",
      icon: <SettingOutlined />,
      label: "Company Settings",
    },
    {
      type: "divider",
    },
    {
      key: "logout",
      icon: <LogoutOutlined />,
      label: "Logout",
      danger: true,
    },
  ];

  return (
    <ConfigProvider
      theme={{
        token: {
          colorPrimary: "#0b6e4f",
          colorInfo: "#0f766e",
          borderRadius: 14,
          fontFamily: "'Avenir Next', 'Segoe UI', sans-serif",
        },
        components: {
          Layout: {
            headerBg: "rgba(255,255,255,0.7)",
            siderBg: "#0f1f2b",
            triggerBg: "#0f1f2b",
          },
          Card: {
            borderRadiusLG: 16,
          },
          Menu: {
            darkItemBg: "#0f1f2b",
            darkItemSelectedBg: "#14532d",
            darkSubMenuItemBg: "#0f1f2b",
          },
        },
      }}
    >
      <AntdApp>
        {contextHolder}
        {!isAuthenticated ? (
          <div className="login-shell">
            <Card className="glass-card login-card">
              <Space direction="vertical" size={12} className="w-full">
                <Typography.Title level={3} className="header-title">
                  Carmak
                </Typography.Title>
                <Typography.Text type="secondary">
                  Sign in to continue to your fleet compliance dashboard.
                </Typography.Text>
                <Form form={loginForm} layout="vertical" requiredMark onFinish={() => void onLogin()}>
                  <Form.Item
                    label="Username"
                    name="username"
                    rules={[{ required: true, message: "Username is required." }]}
                  >
                    <Input placeholder="Username" autoComplete="username" />
                  </Form.Item>
                  <Form.Item
                    label="Password"
                    name="password"
                    rules={[{ required: true, message: "Password is required." }]}
                  >
                    <Input.Password placeholder="Password" autoComplete="current-password" />
                  </Form.Item>
                  <Button type="primary" size="large" htmlType="submit" block>
                    Login
                  </Button>
                </Form>
              </Space>
            </Card>
          </div>
        ) : (
          <>
            <Layout className="app-root">
              <Layout.Sider breakpoint="lg" collapsedWidth={0} width={270}>
                <div className="brand">
                  <Typography.Title level={4} className="brand-title">
                    Carmak
                  </Typography.Title>
                  <Typography.Text className="brand-subtitle">LES Trip Submission Console</Typography.Text>
                </div>
                <Menu
                  theme="dark"
                  mode="inline"
                  selectedKeys={[activeMenu]}
                  items={menuItems}
                  onClick={(event) => {
                    setActiveMenu(event.key as MenuKey);
                  }}
                />
              </Layout.Sider>
              <Layout>
                <Layout.Header className="header">
                  <Space direction="vertical" size={0}>
                    <Typography.Title level={3} className="header-title">
                      Fleet Compliance Dashboard
                    </Typography.Title>
                    <Typography.Text type="secondary">
                      Daily import, validation, and LES submission workflow.
                    </Typography.Text>
                  </Space>
                  <Dropdown menu={{ items: profileMenuItems, onClick: onProfileAction }} trigger={["click"]}>
                    <Button className="profile-menu-btn">
                      <Space size={8}>
                        <Avatar size={26} icon={<UserOutlined />} />
                        <span>Profile</span>
                        <DownOutlined />
                      </Space>
                    </Button>
                  </Dropdown>
                </Layout.Header>
                <Layout.Content className="content">{renderContent()}</Layout.Content>
              </Layout>
            </Layout>
            <Modal
              title="Submitting Trips to LES"
              open={lesModalOpen}
              maskClosable={!lesSubmitting}
              closable={!lesSubmitting}
              onCancel={() => {
                if (!lesSubmitting) setLesModalOpen(false);
              }}
              footer={
                lesSubmitting
                  ? [<Button key="submitting" loading disabled>Submitting...</Button>]
                  : [
                      lesSummary.failed > 0 ? (
                        <Button
                          key="resubmit"
                          icon={<SyncOutlined />}
                          onClick={() => void runLesSubmissionSimulation({ type: "failed-all" })}
                        >
                          Resubmit Failed Trips
                        </Button>
                      ) : null,
                      <Button key="close" onClick={() => setLesModalOpen(false)}>
                        Close
                      </Button>,
                      <Button
                        key="receipt"
                        type="primary"
                        onClick={() => api.success("Submission receipt download will be connected next.")}
                      >
                        Download Submission Receipt
                      </Button>,
                    ]
              }
            >
              <Space direction="vertical" size={14} className="w-full">
                <Typography.Text strong>
                  Trips in this run: {lesSummary.ready} | Submitted: {lesSummary.submitted} | Failed: {lesSummary.failed}
                </Typography.Text>
                {lesLikelyFailureReasons.length > 0 && (
                  <Alert
                    type="warning"
                    showIcon
                    message="Most likely failure reasons"
                    description={
                      <div>
                        {lesLikelyFailureReasons.map((item) => (
                          <div key={item.reason}>
                            {item.reason} ({item.count} trip{item.count > 1 ? "s" : ""})
                          </div>
                        ))}
                      </div>
                    }
                  />
                )}
                <Progress
                  percent={lesProgress}
                  status={lesFailedStageIndex !== null ? "exception" : lesSubmitting ? "active" : "success"}
                />
                <Steps
                  direction="vertical"
                  size="small"
                  current={lesCurrentStage}
                  items={lesSubmissionStages.map((title, index) => {
                    if (lesFailedStageIndex !== null) {
                      if (index < lesFailedStageIndex) return { title, status: "finish" as const };
                      if (index === lesFailedStageIndex) return { title, status: "error" as const };
                      return { title, status: "wait" as const };
                    }
                    if (lesSubmitting) {
                      if (index < lesCurrentStage) return { title, status: "finish" as const };
                      if (index === lesCurrentStage) return { title, status: "process" as const };
                      return { title, status: "wait" as const };
                    }
                    return { title, status: "finish" as const };
                  })}
                />
                <div className="submission-log-box">
                  {lesSubmissionLog.map((line, idx) => (
                    <div key={`${line}-${idx}`}>{line}</div>
                  ))}
                </div>
              </Space>
            </Modal>
          </>
        )}
      </AntdApp>
    </ConfigProvider>
  );
};

export default App;
